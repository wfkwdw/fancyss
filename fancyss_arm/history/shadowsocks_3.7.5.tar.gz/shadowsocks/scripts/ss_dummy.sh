#!/bin/sh
# do not delete this script, it's usefull
echo "dummu script for data store only"
